package com.abdullahaktas.repository.entity;

public enum EAddressType {
    HOME,WORK,OTHER
}
