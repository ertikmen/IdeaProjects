package com.abdullahaktas.repository.entity.enums;

public enum EGEnder {
    MAN,WOMAN,OTHER
}
